import React, { useState } from 'react';
import { Trophy } from 'lucide-react';
import { ShowcaseItem } from './components/ShowcaseItem';
import { AddAchievementForm } from './components/AddAchievementForm';

interface ShowcaseEntry {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
}

function App() {
  const [showcaseItems, setShowcaseItems] = useState<ShowcaseEntry[]>([]);

  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);

  const handleAddNew = () => {
    if (selectedImage && newTitle && newDescription) {
      const imageUrl = URL.createObjectURL(selectedImage);
      setShowcaseItems(prev => [...prev, {
        id: Date.now().toString(),
        title: newTitle,
        description: newDescription,
        imageUrl,
      }]);
      setIsAddingNew(false);
      setNewTitle('');
      setNewDescription('');
      setSelectedImage(null);
    }
  };

  const handleDelete = (id: string) => {
    setShowcaseItems(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-center mb-12 bg-amber-100 py-6 rounded-xl">
          <Trophy className="w-8 h-8 text-amber-500 mr-3" />
          <h1 className="text-4xl font-bold text-amber-800">Digita Showcase</h1>
        </div>

        <div className="mb-8">
          <button
            onClick={() => setIsAddingNew(true)}
            className="bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors duration-300"
          >
            Add New Achievement
          </button>
        </div>

        {isAddingNew && (
          <AddAchievementForm
            title={newTitle}
            description={newDescription}
            onTitleChange={setNewTitle}
            onDescriptionChange={setNewDescription}
            onImageSelect={setSelectedImage}
            onSave={handleAddNew}
            onCancel={() => setIsAddingNew(false)}
            isValid={!!selectedImage && !!newTitle && !!newDescription}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {showcaseItems.map((item) => (
            <ShowcaseItem
              key={item.id}
              title={item.title}
              description={item.description}
              imageUrl={item.imageUrl}
              onDelete={() => handleDelete(item.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;