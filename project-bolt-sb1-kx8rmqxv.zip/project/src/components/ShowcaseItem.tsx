import React from 'react';
import { Trash2 } from 'lucide-react';

interface ShowcaseItemProps {
  title: string;
  description: string;
  imageUrl: string;
  onDelete: () => void;
}

export function ShowcaseItem({ title, description, imageUrl, onDelete }: ShowcaseItemProps) {
  return (
    <div className="bg-blue-50 rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-[1.02] hover:shadow-xl relative group">
      <button
        onClick={onDelete}
        className="absolute top-2 right-2 p-2 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:bg-red-600"
        aria-label="Delete item"
      >
        <Trash2 className="w-4 h-4 text-white" />
      </button>
      <div className="aspect-[4/3] overflow-hidden bg-blue-100">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-blue-900 mb-2">{title}</h3>
        <p className="text-blue-700">{description}</p>
      </div>
    </div>
  );
}