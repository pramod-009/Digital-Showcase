import React from 'react';
import { ImageUpload } from './ImageUpload';

interface AddAchievementFormProps {
  title: string;
  description: string;
  onTitleChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onImageSelect: (file: File) => void;
  onSave: () => void;
  onCancel: () => void;
  isValid: boolean;
}

export function AddAchievementForm({
  title,
  description,
  onTitleChange,
  onDescriptionChange,
  onImageSelect,
  onSave,
  onCancel,
  isValid
}: AddAchievementFormProps) {
  return (
    <div className="bg-emerald-50 p-8 rounded-xl shadow-lg mb-8">
      <h2 className="text-2xl font-semibold mb-6 text-emerald-800">Add New Achievement</h2>
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-emerald-700 mb-2">
            Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => onTitleChange(e.target.value)}
            className="w-full px-4 py-2 border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            placeholder="Enter title"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-emerald-700 mb-2">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => onDescriptionChange(e.target.value)}
            className="w-full px-4 py-2 border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            placeholder="Enter description"
            rows={3}
          />
        </div>
        <ImageUpload onImageSelect={onImageSelect} />
        <div className="flex justify-end space-x-4">
          <button
            onClick={onCancel}
            className="px-4 py-2 border border-emerald-300 rounded-lg hover:bg-emerald-50 text-emerald-700"
          >
            Cancel
          </button>
          <button
            onClick={onSave}
            disabled={!isValid}
            className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}